﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Retail_Bank_UI.Utility
{
    public class EmailOptions
    {
        public string SendGridKey { get; set; }
        public string SendGridUser { get; set; }
    }
}
