﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Retail_Bank_UI.Utility
{
    public class SmsOptions
    {
        public string TwilloSID { get; set; }
        public string TwilloAuth { get; set; }

    }
}
